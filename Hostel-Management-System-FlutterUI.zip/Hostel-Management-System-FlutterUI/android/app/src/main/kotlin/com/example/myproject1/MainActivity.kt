package com.example.myproject1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
